# Html Universal Identifier

Html Universal Identifier is an alpha version of an application designed for identifying server-side HTML parsers. This package provides a way to determine which HTML, SVG, and MathML tags are allowed based on a handler function that processes HTML payloads.

## Features

- Identify allowed HTML, SVG, and MathML tags.
- Use a customizable handler function to process HTML payloads.
- Load and compare results against predefined JSON files.

## Installation

To install the package, use pip:

```
pip install hui
```

## Usage

Here is a basic example of how to use the `Identifier` class from the package:

```python
from hui.identify import Identifier
import requests

def handler(payload):
    return requests.get("http://localhost:3005/sanitize", params={"html": payload}).text

a = Identifier(handler=handler)
print(a.identify())  # Outputs the identification results
print(a.ALLOWED_TAGS)  # Outputs the allowed tags
```

## Identifier Class

The `Identifier` class is the core of this package. It is responsible for identifying allowed HTML, SVG, and MathML tags based on a handler function that processes HTML payloads.

### Constructor Parameters

- **`handler`**: A function that takes a payload and returns an HTML response. Example:
  ```python
  lambda payload: requests.get(f"http://localhost:3000?payload={payload}").text
  ```

- **`buffer_enabled`** (optional, default=True): A boolean flag to enable or disable buffering of payloads before sending them to the handler.

- **`buffer_delimeter`** (optional, default="<div>TEXTTEXT</div>"): A string used to delimit buffered payloads when sending them to the handler.

- **`buffer_limit`** (optional, default=1): An integer that specifies the maximum number of payloads to buffer before sending them to the handler.

### Methods

- **`check_allowed_tags()`**: Checks and populates the `ALLOWED_TAGS` dictionary with allowed tags.
- **`call_handler(template_payload: str)`**: Calls the handler function with a generated payload.
- **`check_namespace(namespace: str)`**: Checks for allowed tags in the specified namespace (HTML, SVG, or MathML).
- **`identify()`**: Identifies the best matching JSON file based on generated payloads and returns a list of matches.

### identify() Method

The `identify()` method checks if allowed tags have been determined. If not, it calls `check_allowed_tags()` to populate the `ALLOWED_TAGS`. It then loads a list of generated payloads from a JSON file and calls the handler for each payload. Finally, it compares the results against all JSON files in the `results_parsers` directory to count matches and returns a sorted list of results.

- **Returns**: A list of tuples, each containing:
  - The match ratio (float)
  - The number of matches (int)
  - The name of the JSON file (str)